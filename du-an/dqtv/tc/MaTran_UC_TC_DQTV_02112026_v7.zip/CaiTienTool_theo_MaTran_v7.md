# Cải tiến tool kiểm theo ma trận UC × TC — DQTV, chỉ dùng tool Console/userscript (02/11/2026)

Đầu vào: ma trận v7 (44.124 TC, 28 loại kiểm thử T01–T28) và tool kiểm giao diện bản 3.25. **Mọi ca chạy bằng chính tool** (Tampermonkey hoặc dán vào Console). Không dùng Playwright, k6 hay bộ chạy ngoài.

## 1. Hiện trạng tool 3.25

- Chỉ đọc mặc định (mức 1): chặn mọi lệnh ghi qua fetch (cổng cài từ document-start), XHR, form POST, sendBeacon, WebSocket; phát hiện yêu cầu đi vòng.
- Đã có khung mức 2/3 (`mucQuyTrinh`): chỉ mở ghi khi tên miền nằm trong `moiTruongKiemThu`.
- Chạy theo đặc tả 2.1 (113 bảng) và cấu hình kiểm 1.0; 18 loại ca; tự chạy tiếp sau khi trang tải lại.
- Hiệu năng: chỉ ghi lời gọi chậm hơn 3 s (api_cham).

**Tool 3.25 chạy được ngay 26.393/44.124 TC (60%).**

## 2. Năm chế độ của tool

| Chế độ | Làm gì | Ghi dữ liệu | Điều kiện bật |
|---|---|---|---|
| M1 Chỉ đọc (mức 1) | khám phá, khói, hồi quy giao diện, đặc tả ô, phân quyền giao diện, kiểm chung đọc được (header, cookie đọc được, trợ năng cơ bản) | Không | mọi môi trường |
| M2 Ghi (mức 2) | tự tạo hồ sơ theo chuỗi bước; luồng chính, ngoại lệ, điều kiện chặn, tách quyền (nối tiếp hai tài khoản), thẩm quyền, độ mật; tệp thử sinh trong trình duyệt; kiểm soát đầu vào ô chữ bằng bộ mẫu thử của Bên A | Có | môi trường kiểm + tài khoản kiểm thử + xác nhận trong Console |
| M3 Ghi lại – phát lại (mức 3) | ghi lại lời gọi ghi ở M2, xuất tệp; đăng nhập tài khoản khác, nạp tệp, phát lại: vai khác, chặng khác, đơn vị khác, gửi lặp, gửi đồng thời, thử sửa nhật ký | Có | như M2 |
| M4 Đo hiệu năng | chỉ số web (LCP, INP, CLS, long task), thời gian API, mở form, ghi bước (cùng M2), đăng nhập (userscript nạp từ trang đăng nhập) | Không (HN-06/08/09 cần M2) | mọi môi trường |
| M5 Tải nhẹ | nhiều luồng trong một tab; nhiều tab, nhiều máy hẹn giờ chung, mỗi tab một tài khoản; kéo dài; gộp kết quả | Mặc định không | lịch thống nhất với Bên B |

Ngoài tool: kết quả quét VSP (đã có), rà đặc tả và nghiệm thu (Bên A làm tay).

Nguyên tắc an toàn: mức 1 không bao giờ ghi. Mức 2/3/5 có ghi chỉ chạy khi đủ cả ba điều kiện: môi trường kiểm, tài khoản kiểm thử, người chạy xác nhận. Hồ sơ tool tạo có tiền tố `[KT-yyyymmdd]`. Nhật ký lời gọi ghi được lưu để Bên B soát.

## 3. Ánh xạ loại kiểm thử × chế độ

| Loại | Tên | Tổng | 3.25 chạy ngay | M1 | M2 | M3 | M4 | M5 | VSP | Rà tay | Ngoài tool |
|---|---|---|---|---|---|---|---|---|---|---|---|
| T01 | Chức năng — luồng chính | 1736 | 0 |  | 1736 |  |  |  |  |  |  |
| T02 | Chức năng — luồng thay thế, ngoại lệ | 308 | 0 |  | 308 |  |  |  |  |  |  |
| T03 | Dữ liệu nhập — phân lớp, biên | 5855 | 5855 | 5855 |  |  |  |  |  |  |  |
| T04 | Biểu mẫu — đặc tả ô | 5825 | 5825 | 5825 |  |  |  |  |  |  |  |
| T05 | Quy tắc nghiệp vụ | 3998 | 233 |  | 3765 |  |  |  |  | 233 |  |
| T06 | Máy trạng thái — sai chặng | 1486 | 1460 | 1460 | 26 |  |  |  |  |  |  |
| T07 | Phân quyền giao diện | 3365 | 3357 | 3357 | 8 |  |  |  |  |  |  |
| T08 | Phân quyền máy chủ | 2807 | 0 |  | 5 | 2802 |  |  |  |  |  |
| T09 | Phạm vi dữ liệu | 326 | 109 | 109 | 3 | 214 |  |  |  |  |  |
| T10 | Xác thực và phiên | 154 | 1 |  |  | 153 |  |  | 1 |  |  |
| T11 | Kiểm soát đầu vào | 1017 | 8 | 109 | 682 | 218 |  |  | 8 |  |  |
| T12 | Toàn vẹn, đồng thời | 1204 | 0 |  |  | 1204 |  |  |  |  |  |
| T13 | Nhật ký, truy vết | 114 | 0 |  | 7 | 107 |  |  |  |  |  |
| T14 | Bảo vệ dữ liệu, văn bản mật | 14 | 0 | 1 | 8 | 5 |  |  |  |  |  |
| T15 | Tách nhiệm vụ, thẩm quyền, uỷ quyền | 295 | 13 |  | 282 |  |  |  |  | 13 |  |
| T16 | Tích hợp, liên quy trình | 495 | 7 | 7 | 488 |  |  |  |  |  |  |
| T17 | Tệp đính kèm, nhập/xuất | 1551 | 0 |  | 1551 |  |  |  |  |  |  |
| T18 | Giao diện, khả dụng | 24 | 0 | 24 |  |  |  |  |  |  |  |
| T19 | Tương thích | 110 | 0 | 110 |  |  |  |  |  |  |  |
| T20 | Hiệu năng — thời gian phản hồi | 3557 | 1 | 1 |  |  | 3556 |  |  |  |  |
| T21 | Tải, chịu tải | 16 | 0 |  |  |  | 2 | 12 |  |  | 2 |
| T22 | Chống quá tải ứng dụng | 224 | 0 |  | 5 | 219 |  |  |  |  |  |
| T23 | Cấu hình, hạ tầng, bí mật | 29 | 25 | 4 |  |  |  |  | 25 |  |  |
| T24 | Thư viện phụ thuộc | 35 | 35 |  |  |  |  |  | 35 |  |  |
| T25 | Hồi quy | 8721 | 8716 | 5047 | 2 |  |  |  |  | 3672 |  |
| T26 | Chấp nhận, pháp lý | 666 | 666 |  |  |  |  |  |  | 666 |  |
| T27 | Nhất quán đặc tả | 82 | 82 |  |  |  |  |  |  | 82 |  |
| T28 | Trợ năng | 110 | 0 | 110 |  |  |  |  |  |  |  |

## 4. Ánh xạ loại ca

| Loại ca | Chế độ | Có trong 3.25 | Số TC |
|---|---|---|---|
| NHAP | M1 | Có | 8041 |
| LOP4 → GHI (mới) | M2 | Không | 6273 |
| TRUONG | M1 | Có | 5438 |
| PHAT_LAI (mới) | M3 | Không | 4917 |
| LOP4 | Rà | Có | 3672 |
| DUNG | M1 | Có | 2162 |
| SAI_VAI | M1 | Có | 2162 |
| XAC_NHAN | M1 | Có | 2162 |
| HN_DO + GHI (mới) | M4 | Không | 2046 |
| TEP (mới, tệp thử sinh trong trình duyệt) | M2 | Không | 1551 |
| HN_DO (mới) | M4 | Không | 1512 |
| SAI_TRANG_THAI | M1 | Có | 1460 |
| rà đặc tả / nghiệm thu | Rà | Có | 994 |
| DAU_VAO (mới, bộ mẫu thử của Bên A) | M2 | Không | 677 |
| KB_CHAY (LOP4 → mới) | M2 | Không | 375 |
| DAU_VAO (mới, ô tìm, chỉ đọc) | M1 | Không | 109 |
| PHAM_VI | M1 | Có | 109 |
| TRO_NANG (mới, kiểm cơ bản) | M1 | Không | 109 |
| TUONG_THICH (chạy tool trên nhiều trình duyệt) | M1 | Không | 109 |
| XEM | M1 | Có | 109 |
| Kết quả VSP (có sẵn) | Kết | Có | 69 |
| KHUNG_CHUNG (mới, chỉ đọc) | M1 | Không | 27 |
| TAI_NHE (mới) | M5 | Không | 12 |
| TRUONG_THUA | M1 | Có | 7 |
| GHI_PHAT_LAI (mới) | M3 | Không | 5 |
| TRUONG_NOI | M1 | Có | 5 |
| CAU_HINH (mới, đọc header/phản hồi) | M1 | Không | 4 |
| DUNG (đảo) | M1 | Không | 3 |
| chuỗi (có sẵn phần đọc) | M1 | Có | 2 |
| Ngoài khả năng tool | Ngoài | Không | 2 |
| api_cham (có sẵn) | M1 | Có | 1 |

Quy ước mã TC giữ như tool đang sinh: `<quy trình>.<bước>.<loại ca>[.<ô>][.<biến thể>]`. Loại mới: `.HN.MO_FORM`, `.HN.DANH_SACH`, `.HN.CHI_TIET`, `.HN.TIM`, `.HN.TONG_HOP.<XA|TINH|QK|CUC>`, `.HN.GHI`, `.HN.XUAT`, `.TEP.<ô>.HN`, `CHUNG.HN.DANG_NHAP.<vai>`, `CHUNG.TAI.*`.

## 5. Ánh xạ kết quả tool → ma trận

| Kết quả tool | Ghi vào «Kết quả chạy» | Xử lý |
|---|---|---|
| ĐẠT | Đạt | — |
| LỆCH | Không đạt | Lệch UC đã duyệt → phân loại: lỗi app |
| CẢNH BÁO | Không đạt (chờ phân loại) | Lệch tài liệu Bên B chưa duyệt → phân loại: lỗi app hoặc lệch tài liệu |
| CHƯA KIỂM | Chưa chạy được | Ghi lý do: thiếu hồ sơ ở chặng, thiếu tài khoản, điều kiện dữ liệu… (T27 nếu đặc tả không tới được chặng) |
| LỚP 4 | Chuyển bộ chạy R2/R3 | Ca cần ghi dữ liệu, không chạy ở R1 |
| KHONG_VAO_MAN | Chưa chạy được | Vai không vào được màn: kiểm lại quyền xem (T07) |
| Chặn ghi (BLOCK) | Thông tin | Không phải lỗi app; dùng xác nhận ca «mở form không ghi ngay» (XAC_NHAN) |
| Đi vòng bộ chặn | Dừng lần chạy | Lỗi an toàn của tool, không tính vào ma trận |

## 6. Đặc tả 2.2 và cấu hình kiểm 1.1

| Ở đâu | Trường | Kiểu | Ý nghĩa | Ví dụ |
|---|---|---|---|---|
| bảng | `tc[]` | mảng | Danh sách TC của bảng không gắn bước (XEM, PHAM_VI, HN-02…) | `{"ma":"1.HN.DANH_SACH","loai_kiem":"T20","uu_tien":"Trung bình","che_do":"M1","hieu_nang":"HN-02"}` |
| bước | `tc[]` | mảng | TC của bước: ma, loai_kiem, uu_tien, lop_kiem, can_cu, bo_chay | `{"ma":"1.B3a.SAI_VAI","loai_kiem":"T07","uu_tien":"Cao","che_do":"M1","can_cu":"tai-lieu/qt-1.md mục 7 bước 3a"}` |
| bước | `chuan_bi` | mảng mã bước | Chuỗi bước tạo hồ sơ tới «Từ chặng» (M2 dùng; M1 dùng ho_so_mau nếu có) | `["B1","B2"]` |
| bước | `hieu_nang` | đối tượng | Mốc đo HN-05/HN-06 của bước | `{"mo_form":{"nguong_ms":1000,"lap":10},"ghi":{"nguong_ms":2000,"lap":30}}` |
| bảng | `hieu_nang.man[]` | mảng | Màn cần đo HN-02/03/04/07: đường dẫn, lớp, ngưỡng, lặp, bộ đệm | `{"duong_dan":"/dqtv/incoming-documents","lop":"HN-02","nguong_ms":1000,"lap":30,"bo_dem":"lanh_nong"}` |
| cấu hình kiểm | `hieu_nang` | phần mới (8) | Ngưỡng chung, số lần lặp, chế độ đo (tắt quét trường), cách tổng hợp | `{"lcp_ms":2500,"inp_ms":200,"cls":0.1,"api_doc_ms":1000,"api_ghi_ms":2000,"che_do_do":true}` |
| cấu hình kiểm | `ke_hoach.loai_kiem / uu_tien / bo_chay` | mảng | Lọc kế hoạch theo ma trận | `{"bo":"theo_ma_tran","loai_kiem":["T06","T07"],"uu_tien":["Cao"]}` |
| cấu hình kiểm | `moi_truong.duong_dan_xac_thuc` | mảng | Thay choPhepPost: đúng các đường dẫn xác thực được phép POST | `["/api/auth/login","/api/auth/refresh-session"]` |

Phần `hieu_nang` mẫu: tệp `cau_hinh_kiem_hieu_nang.json` kèm theo.

## 7. UC hiệu năng

| Lớp | Tên | Chỉ số đo | Ngưỡng p95 mặc định | Lặp | Chế độ | Số TC |
|---|---|---|---|---|---|---|
| HN-01 | Đăng nhập tới trang chủ theo vai | TTFB; LCP; thời gian tới khi menu theo vai hiện đủ; số lời gọi; dung lượng tải | TTFB ≤ 800 ms; LCP ≤ 2,5 s; menu đủ ≤ 3 s | 20 | M4 Tool đo hiệu năng (userscript nạp từ trang đăng nhập) | 37 |
| HN-02 | Mở màn danh sách | LCP; CLS; thời gian lời gọi danh sách; số dòng; dung lượng phản hồi | API danh sách ≤ 1 s; LCP ≤ 2,5 s; CLS ≤ 0,1 | 30 | M4 Tool đo hiệu năng | 114 |
| HN-03 | Mở hồ sơ chi tiết | thời gian lời gọi chi tiết; thời gian tới khi đủ nút bước; long task | API chi tiết ≤ 800 ms; đủ nút ≤ 2 s | 30 | M4 Tool đo hiệu năng | 109 |
| HN-04 | Tìm kiếm, lọc | INP của thao tác gõ/lọc; thời gian lời gọi tìm; số lời gọi mỗi lần gõ | kết quả ≤ 1,5 s; INP ≤ 200 ms; không gọi mỗi phím (có debounce) | 30 | M4 Tool đo hiệu năng | 109 |
| HN-05 | Mở biểu mẫu của bước | thời gian từ bấm nút tới khi form sẵn sàng (mọi ô chọn đã có lựa chọn); số lời gọi nạp danh mục | form sẵn sàng ≤ 1 s; danh mục ≤ 1 s | 10 | M4 Tool đo hiệu năng | 1125 |
| HN-06 | Ghi bước (Lưu, xác nhận) | thời gian lời gọi ghi; thời gian tới khi chặng mới hiện; số lời gọi sau ghi | API ghi ≤ 2 s; chặng mới hiện ≤ 3 s | 30 | M4 Tool đo hiệu năng + M2 ghi (môi trường kiểm) | 1627 |
| HN-07 | Màn tổng hợp theo cấp | thời gian lời gọi tổng hợp; LCP; theo cấp xã / tỉnh / quân khu / Cục | xã ≤ 2 s; tỉnh ≤ 3 s; quân khu, Cục ≤ 5 s | 20 | M4 Tool đo hiệu năng | 16 |
| HN-08 | Xuất tệp (Excel, PDF) | thời gian tạo và tải tệp; dung lượng; bộ nhớ trình duyệt | 10.000 dòng ≤ 10 s | 5 | M4 Tool đo hiệu năng | 109 |
| HN-09 | Tải tệp lên, tải về | thời gian tải lên tệp 1 MB / 10 MB; thời gian tải về | 10 MB lên ≤ 5 s; tải về ≤ 3 s | 10 | M4 Tool đo hiệu năng + M2 ghi; tệp thử sinh trong trình duyệt | 310 |
| HN-00 | Quan sát lời gọi chậm khi kiểm giao diện | mọi lời gọi > ngưỡng trong lúc chạy kiểm giao diện | không có lời gọi > 3 s | 1 | M1 Tool chỉ đọc (có sẵn: api_cham) | 1 |

### Kịch bản tải (T21) bằng tool

| Mã | Tên | Mô hình (bằng tool) | Tiêu chí đạt | Khả năng bằng tool |
|---|---|---|---|---|
| CHUNG.TAI.CO_SO | Đo cơ sở | M4: mỗi vai một lần chạy đo, 1 tab | ghi p50/p95/p99 gốc; 0 lỗi | Đủ |
| CHUNG.TAI.DONG_THOI_NHE | Đồng thời nhẹ một máy | M5: 1 tab, K luồng đọc song song (K = 5, 10, 20), lặp theo trộn thao tác, 15 phút | p95 ≤ 1,5 × cơ sở; lỗi < 1% | Đủ |
| CHUNG.TAI.NHIEU_MAY | Tải phân tán nhiều máy | M5: T máy × 1–3 tab, mỗi tab một tài khoản kiểm thử khác vai/đơn vị, cùng giờ bắt đầu (đặt trong cấu hình), mỗi tab K luồng; 30 phút | p95 ≤ 1,5 × cơ sở và trong ngưỡng HN; lỗi < 1% | Một phần: quy mô bằng số máy × tab × luồng (vài chục đến vài trăm luồng), không đạt hàng nghìn người dùng |
| CHUNG.TAI.DOT_BIEN_NHE | Đột biến nhỏ | M5: mọi tab bắt đầu cùng giây, giữ 5 phút | lỗi < 2%; hồi phục ≤ 2 phút | Một phần |
| CHUNG.TAI.KEO_DAI | Chạy kéo dài | M5: 1–3 tab chạy 8 giờ, ghi bộ nhớ heap của tab (performance.memory nếu có) và p95 theo giờ | p95 không trôi > 20%; heap tab không tăng liên tục | Đủ (phía một người dùng) |
| CHUNG.TAI.DUOI_TAI | Trải nghiệm dưới tải | M4 ở một máy trong lúc NHIEU_MAY chạy | LCP, INP ≤ 1,5 × cơ sở | Đủ |
| CHUNG.TAI.DINH.BAO_CAO_DINH_KY | Đỉnh nhỏ: nộp báo cáo định kỳ (qt-5) | M5 + M2: mỗi tab một tài khoản Trợ lý xã, làm chuỗi lập → trình (môi trường kiểm), cùng giờ | không mất báo cáo; p95 trong ngưỡng HN-06 | Một phần |
| CHUNG.TAI.DINH.TONG_QUAN | Đỉnh nhỏ: Tổng quan lực lượng cấp trên | M5: mọi tài khoản cấp tỉnh/quân khu/Cục kiểm thử mở cùng lúc, 10 phút | p95 HN-07 trong ngưỡng | Một phần |
| CHUNG.TAI.TANG_DAN | Tăng dần tới giới hạn | Không làm được bằng tool trong trình duyệt | xác định công suất tối đa | Ngoài khả năng tool — cần quyết định của Bên A |
| CHUNG.TAI.CONG_SUAT | Kiểm công suất | Không làm được bằng tool trong trình duyệt | bảng công suất theo bậc | Ngoài khả năng tool — cần quyết định của Bên A |
| CHUNG.TAI.KHOI_LUONG | Khối lượng dữ liệu toàn quốc | Tool chỉ đo được (M4) khi dữ liệu đã có; không tự nạp được khối lượng này | danh sách phân trang ở máy chủ; ngưỡng HN giữ | Một phần: đo được, không tạo được dữ liệu |
| CHUNG.TAI.PHUC_HOI | Phục hồi sau sự cố | M5 chạy; Bên B khởi động lại theo lịch; tool ghi thời điểm lỗi và thời điểm hồi phục | không ghi hỏng dữ liệu; phục hồi ≤ 5 phút | Một phần (cần Bên B phối hợp) |

**Giới hạn cần nói rõ:** tool chạy trong trình duyệt nên tải tạo ra bằng số máy × số tab × số luồng mỗi tab (ví dụ 10 máy × 3 tab × 10 luồng ≈ 300 luồng đọc song song). Mỗi tab dùng một phiên đăng nhập; trình duyệt giới hạn số kết nối tới một máy chủ. Vì vậy:
- Đo được chắc chắn: số đo cơ sở, trải nghiệm người dùng (HN-01…09), đồng thời nhẹ, chạy kéo dài, trải nghiệm dưới tải.
- Đo được một phần: tải nhiều máy, đột biến nhỏ, đỉnh nghiệp vụ nhỏ — kết quả ghi rõ quy mô thực tế (số máy, tab, luồng).
- **Không làm được bằng tool:** tăng dần tới điểm gãy và kiểm công suất ở quy mô toàn quốc (≈ 2.674 người dùng đồng thời). Hai TC này ghi «Ngoài khả năng tool». Nếu Phụ lục 01 đòi chứng minh công suất. Bên A cần quyết định cách khác (ví dụ yêu cầu Bên B nộp kết quả tải có giám sát. Bên A chứng kiến).

## 8. Backlog cải tiến tool

| Mã | Ưu tiên | Hạng mục | Việc | Tiêu chí nghiệm thu | Phục vụ |
|---|---|---|---|---|---|
| CT-01 | P0 | An toàn | Siết choPhepPost: bỏ extend, renew, refresh, search, query; chỉ cho POST tới đúng đường dẫn xác thực khai trong cấu hình (moi_truong.duong_dan_xac_thuc). | Tự kiểm của tool: lời gọi ghi nghiệp vụ (kể cả /…/extend) bị chặn ở mức 1; đăng nhập, giữ phiên vẫn chạy | M1 |
| CT-02 | P0 | An toàn | Bộ tự kiểm chặn ghi chạy trong Console (dqtv.tuKiemChan()): thử fetch (tham chiếu cũ), XHR, form POST, sendBeacon, WebSocket tới một đường dẫn giả; kiểm Service Worker (navigator.serviceWorker.controller → cảnh báo, ngừng bấm). | Mỗi lần nạp tool tự chạy; 100% đạt mới cho bấm Chạy | M1 |
| CT-03 | P0 | An toàn | Khoá chế độ ghi: mức 2/3/5 chỉ bật khi tên miền nằm trong moi_truong (kiểm thử), tài khoản nằm trong tai_khoan (kiểm thử), người chạy gõ xác nhận trong Console; mọi hồ sơ tool tạo mang tiền tố [KT-yyyymmdd]; nhật ký lời gọi ghi lưu lại để Bên B soát. | Không bật được ghi ở môi trường/tài khoản ngoài danh sách | M2 M3 M5 |
| CT-04 | P1 | Dữ liệu | Tách đặc tả khỏi mã: userscript chỉ chứa mã; đặc tả 2.2 và cấu hình kiểm nạp bằng dqtv.napDacTa(tệp) / dán JSON, lưu IndexedDB, có mã băm. | userscript < 300 KB; báo cáo ghi mã băm | Tất cả |
| CT-05 | P1 | Đặc tả | Đặc tả 2.2 (tương thích 2.1): tc[] (ma, loai_kiem, uu_tien, lop_kiem, can_cu, che_do), chuan_bi (chuỗi bước), hieu_nang (màn, form, ngưỡng). | Nạp được 2.1 và 2.2; kiểm lược đồ khi nạp | Tất cả |
| CT-06 | P1 | Kế hoạch | ke_hoach chọn theo ma trận: loai_kiem, uu_tien, che_do (M1…M5), quy_trinh, ma_tc; bộ dựng sẵn: khoi, hoi_quy_ui, hieu_nang_don, theo_loi_mo, ghi_luong_chinh. | dqtv.keHoach({loai_kiem:["T06","T07"]}) chạy đúng tập TC | Tất cả |
| CT-07 | P1 | Kết quả | Xuất kết quả theo mã TC (dqtv.xuat("ket-qua-ma-tran")): ma_tc, ket_qua, phan_loai, ly_do, thoi_diem, tai_khoan, ban_tool, bam_dac_ta, bam_cau_hinh, chi_so. Gộp nhiều lần chạy (nhiều tài khoản, nhiều máy) bằng dqtv.gopKetQua(tệp…). | Nạp ngược vào ma trận không sót mã | Tất cả |
| CT-08 | P1 | Kết quả | Phân loại nguyên nhân khi không đạt: lỗi app / lệch tài liệu Bên B / dương tính giả / môi trường. | Mỗi dòng không đạt có phân loại | Tất cả |
| CT-09 | P1 | M4 Hiệu năng | Module đo: PerformanceObserver (largest-contentful-paint, layout-shift, event → INP, longtask, navigation, resource); mốc theo màn, theo form, theo bước ghi; lặp N lần; p50/p95/p99; userscript nạp từ trang đăng nhập để đo HN-01. | Sai số lặp lại < 10%; ghi đúng mã .HN.* | T20 |
| CT-10 | P1 | M4 Hiệu năng | Chế độ đo: tắt quét trường, không clone/parse thân phản hồi, không lưu thân JSON; đo HN-05 từ luồng moVaQuetForm sẵn có. | Chênh số đo bật/tắt tool < 5% | T20 |
| CT-11 | P2 | M2 Ghi | Chế độ ghi (mức 2, môi trường kiểm): tự tạo hồ sơ theo chuan_bi (bấm nút, nhập dữ liệu kiểm thử từ tu_dien_du_lieu, Lưu); chạy KB, ca DONG, CHAN, LY_DO, PHAN_TACH (nối tiếp hai tài khoản), THAM_QUYEN, DO_MAT; đo HN-06; tệp thử sinh trong trình duyệt (Blob + DataTransfer) cho T17, HN-09. | Chạy được một quy trình đầu-cuối và bộ ca của nó; dữ liệu tạo ra có tiền tố KT | T01 T02 T05 T15 T16 T17 |
| CT-12 | P2 | M3 Ghi lại – phát lại | Ghi lại lời gọi ghi ở M2 (phương thức, đường dẫn, thân; che giá trị nhạy cảm) → xuất tệp. Đăng nhập tài khoản khác, nạp tệp, phát lại theo TC: vai khác, hồ sơ ở chặng khác, id hồ sơ đơn vị khác, gửi lặp, gửi đồng thời (Promise.all), thử sửa nhật ký. | Kết quả theo mã TC T08/T09/T10/T12/T13; chỉ chạy ở môi trường kiểm | T08 T09 T10 T12 T13 |
| CT-13 | P2 | M5 Tải nhẹ | Tải nhẹ trong trình duyệt: K luồng song song trong 1 tab theo trộn thao tác (chỉ đọc mặc định; ghi khi mức 2); hẹn giờ bắt đầu chung cho nhiều tab/máy; mỗi tab ghi p50/p95/p99, lỗi; gộp bằng dqtv.gopKetQua. | Chạy DONG_THOI_NHE, NHIEU_MAY, KEO_DAI; báo cáo gộp nhiều máy | T21 |
| CT-14 | P2 | Phiên nối tiếp | Chạy nối tiếp nhiều tài khoản: tool lưu tiến độ, báo «đăng xuất, đăng nhập tài khoản X», tự chạy tiếp phần của tài khoản đó (đã có cơ chế chạy tiếp sau tải lại); không lưu mật khẩu. | Một kế hoạch đa vai chạy hết qua nhiều lần đăng nhập | T07 T08 T09 T15 |
| CT-15 | P2 | Mã TC, báo cáo | Tool sinh mã đúng quy ước ma trận cho mọi loại ca (kể cả .HN.*, CHUNG.TAI.*); báo cáo có cột Txx, ưu tiên, chế độ; trang tổng hợp Txx × kết quả. | 100% kết quả có mã trong ma trận | Tất cả |
| CT-16 | P3 | Kiểm chung | Thêm các kiểm chỉ đọc: header bảo mật và cờ cookie đọc được (T23, T10 phần đọc), trợ năng cơ bản (nhãn, thứ tự focus, độ tương phản — T28), ghi UA và kích thước cửa sổ cho T19. | Có kết quả cho các TC KHUNG-CHUNG, CHUNG.HEADER, *.TRO_NANG | T10 T19 T23 T28 |

## 9. Lộ trình

1. **3.26 (P0–P1):** CT-01, 02, 03 (an toàn) → CT-04, 05 (đặc tả 2.2) → CT-06, 07, 08 (kế hoạch, kết quả theo mã TC, phân loại) → CT-09, 10 (M4 đo hiệu năng). Sau bản này: M1 + M4 chạy được, kết quả nạp ngược ma trận.
2. **3.27 (P2):** CT-11 (M2 ghi, tạo dữ liệu theo chuỗi bước), CT-14 (chạy nối tiếp nhiều tài khoản).
3. **3.28 (P2):** CT-12 (M3 ghi lại – phát lại), CT-13 (M5 tải nhẹ), CT-15 (mã, báo cáo).
4. **3.29 (P3):** CT-16 (kiểm chung: header, cookie đọc được, trợ năng, tương thích).

## 10. Tiêu chí nghiệm thu bộ tool

- 100% kết quả có mã TC nằm trong ma trận; gộp nhiều lần chạy, nhiều máy không sót, không trùng.
- Mức 1 không để lọt lệnh ghi (bộ tự kiểm CT-02 đạt mỗi lần nạp).
- Mức 2/3/5 không bật được ngoài môi trường và tài khoản kiểm thử.
- Số đo hiệu năng lặp lại được: sai số giữa hai lần chạy < 10%; bật/tắt tool chênh < 5%.
- Mỗi lần chạy ghi: bản tool, mã băm đặc tả, mã băm cấu hình, tài khoản, môi trường, chế độ, số máy/tab/luồng (M5).
